dbPassword = 'mongo adresi';

module.exports = {
    mongoURI: dbPassword
};
