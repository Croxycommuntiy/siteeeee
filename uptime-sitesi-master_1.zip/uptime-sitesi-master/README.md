# uptime-sitesi

# Hi guys welcom to my mongo db tutorial şaka şaka bakın şimdi girin kayıt olun sonra ekrana şu gelicek

![Test Image 1](https://cdn.discordapp.com/attachments/763742452511146025/786354781756719104/1l2km.png)

# Buradan açın clusteri sonra gidin free yi şeçin işte o kadar sonra network ayarlarına gelin

![Test Image 1](https://cdn.discordapp.com/attachments/763742452511146025/786355078151274576/ygx6u.png)

# Bu şekilde network acces açın sonra network accesin üstündeki database accesden read and write admin açınız sonra clusters sayfasındaki clusterinizdkei connete basıp connet app diyin ordaki linki kopyalayın kendi ayarlarınıza göre doldurun

![Test Image 1](https://raksix.wtf/resim/fs2o1.gif)
